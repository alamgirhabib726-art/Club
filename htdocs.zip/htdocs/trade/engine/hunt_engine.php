<?php
/**
 * ============================================
 * UC SMART HUNT ENGINE
 * File: /trade/engine/hunt_engine.php
 * ============================================
 */

if (!defined('UC_ENGINE')) {
    die("DIRECT ACCESS BLOCKED");
}

/* ================= CONFIG ================= */

define('HUNT_STRENGTH_LOW', 0.2);   // slow drift
define('HUNT_STRENGTH_MED', 0.5);
define('HUNT_STRENGTH_HIGH', 1.0);  // fast hunt

/* ================= CORE ================= */

/**
 * Decide market bias based on open positions
 *
 * @param array $positions
 * @return array [direction, speedMultiplier]
 */
function hunt_decision(array $positions): array
{
    $count = count($positions);

    // No traders → free fast market
    if ($count === 0) {
        return [random_direction(), 1.8];
    }

    // One trader → move against him slowly
    if ($count === 1) {
        $p = $positions[0];
        return [
            -$p['direction'],
            HUNT_STRENGTH_LOW
        ];
    }

    // Multiple traders → hunt weakest leverage + biggest size
    usort($positions, function ($a, $b) {
        $scoreA = $a['margin'] / max($a['leverage'], 1);
        $scoreB = $b['margin'] / max($b['leverage'], 1);
        return $scoreB <=> $scoreA;
    });

    $target = $positions[0];

    // Aggressive hunt
    return [
        -$target['direction'],
        HUNT_STRENGTH_HIGH
    ];
}

/* ================= HELPERS ================= */

function random_direction(): int
{
    return rand(0, 1) ? 1 : -1;
}