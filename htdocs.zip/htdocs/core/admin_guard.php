<?php
/**
 * =========================================
 * ADMIN GUARD
 * Private Club System
 * -----------------------------------------
 * - Blocks non-admin access
 * - Zero bypass
 * - Centralized authority check
 * =========================================
 */

require_once __DIR__ . '/auth.php';

/* -----------------------------------------
   AUTH CHECK
------------------------------------------ */
if (!auth_check()) {
    http_response_code(401);
    die("UNAUTHORIZED: Login required.");
}

/* -----------------------------------------
   ROLE CHECK
------------------------------------------ */
if (!auth_is_admin()) {
    http_response_code(403);
    die("FORBIDDEN: Admin access only.");
}

/* -----------------------------------------
   OPTIONAL: SESSION TIMEOUT (HARD)
------------------------------------------ */
$MAX_SESSION_TIME = 60 * 60 * 4; // 4 hours

if (isset($_SESSION['login_time']) &&
    (time() - $_SESSION['login_time']) > $MAX_SESSION_TIME) {

    auth_logout();
    http_response_code(401);
    die("SESSION EXPIRED: Please login again.");
}

/* -----------------------------------------
   ADMIN IS CLEARED
------------------------------------------ */
// If execution reaches here → admin is trusted