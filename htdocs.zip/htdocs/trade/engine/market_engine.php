<?php
/**
 * ============================================
 * UC MARKET → CHART DATA API (STABLE)
 * ============================================
 * InfinityFree safe
 * Lightweight Charts compatible
 */

require_once __DIR__ . "/../../db.php";

header("Content-Type: application/json");

/* ================= TIMEFRAME ================= */
$tf = $_GET['tf'] ?? '1m';

$map = [
    '1m'  => 60,
    '5m'  => 300,
    '15m' => 900,
    '1h'  => 3600,
];

$interval = $map[$tf] ?? 60;

/* ================= FETCH LIMITED RAW DATA ================= */
$stmt = $db->prepare("
    SELECT price, UNIX_TIMESTAMP(created_at) AS t
    FROM uc_market
    ORDER BY created_at DESC
    LIMIT 1500
");
$stmt->execute();
$rows = array_reverse($stmt->fetchAll(PDO::FETCH_ASSOC));

if (!$rows) {
    echo json_encode([]);
    exit;
}

/* ================= BUILD CANDLES ================= */
$candles = [];
$bucket = [];

foreach ($rows as $r) {

    $ts = (int)$r['t'];
    if ($ts <= 0) continue;

    $bucketTime = floor($ts / $interval) * $interval;

    if (!isset($bucket[$bucketTime])) {
        $bucket[$bucketTime] = [
            'time'  => $bucketTime,
            'open'  => (float)$r['price'],
            'high'  => (float)$r['price'],
            'low'   => (float)$r['price'],
            'close' => (float)$r['price'],
        ];
    } else {
        $bucket[$bucketTime]['high'] =
            max($bucket[$bucketTime]['high'], $r['price']);
        $bucket[$bucketTime]['low'] =
            min($bucket[$bucketTime]['low'], $r['price']);
        $bucket[$bucketTime]['close'] =
            (float)$r['price'];
    }
}

/* ================= FINAL OUTPUT ================= */
$out = [];

foreach ($bucket as $c) {
    $out[] = [
        'time'  => (int)$c['time'],
        'open'  => round($c['open'], 4),
        'high'  => round($c['high'], 4),
        'low'   => round($c['low'], 4),
        'close' => round($c['close'], 4),
    ];
}

echo json_encode($out);