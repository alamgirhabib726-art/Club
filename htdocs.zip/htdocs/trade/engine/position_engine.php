<?php
/**
 * ============================================
 * UC POSITION ENGINE
 * File: /trade/engine/position_engine.php
 * ============================================
 */

if (!defined('UC_ENGINE')) {
    die("DIRECT ACCESS BLOCKED");
}

/* ================= CONFIG ================= */

define('MIN_LEVERAGE', 5);
define('MAX_LEVERAGE', 100);

/* Liquidation buffer (hidden from user) */
define('LIQUIDATION_BUFFER', 0.02); // 2%

/* ================= OPEN POSITION ================= */

function open_position(
    int $userId,
    float $margin,
    int $leverage,
    int $direction,
    float $price
): array {

    if ($leverage < MIN_LEVERAGE || $leverage > MAX_LEVERAGE) {
        return ['error' => 'Invalid leverage'];
    }

    if ($margin <= 0) {
        return ['error' => 'Invalid margin'];
    }

    $positionSize = $margin * $leverage;

    $fee = calculate_fee($margin, $leverage);

    return [
        'user_id'        => $userId,
        'margin'         => $margin,
        'leverage'       => $leverage,
        'direction'      => $direction, // 1 = long, -1 = short
        'entry_price'    => $price,
        'position_size'  => $positionSize,
        'fee'            => $fee,
        'liquidation_px' => liquidation_price($price, $leverage, $direction),
        'status'         => 'open'
    ];
}

/* ================= CLOSE POSITION ================= */

function close_position(array $position, float $exitPrice): float
{
    $pnl = calculate_pnl($position, $exitPrice);

    return $pnl - $position['fee'];
}

/* ================= LIQUIDATION ================= */

function is_liquidated(array $position, float $price): bool
{
    if ($position['direction'] === 1) {
        return $price <= $position['liquidation_px'];
    }
    return $price >= $position['liquidation_px'];
}

/* ================= HELPERS ================= */

function liquidation_price(float $price, int $leverage, int $dir): float
{
    $move = (1 / $leverage) + LIQUIDATION_BUFFER;

    return $dir === 1
        ? $price * (1 - $move)
        : $price * (1 + $move);
}

function calculate_pnl(array $p, float $exit): float
{
    $diff = ($exit - $p['entry_price']) * $p['direction'];
    return ($diff / $p['entry_price']) * $p['position_size'];
}

function calculate_fee(float $margin, int $leverage): float
{
    /*
      Fee logic:
      - 5x → 0.2%
      - 10x → 0.4%
      - 50x → 1.2%
      - 100x → 2%
    */
    $rate = 0.002 + (($leverage - 5) / 95) * 0.018;
    return round($margin * $rate, 4);
}