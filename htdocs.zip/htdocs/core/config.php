<?php
/**
 * =========================================
 * SYSTEM CONFIGURATION
 * Private Club Platform
 * =========================================
 */

/* -----------------------------------------
   BASIC IDENTITY
------------------------------------------ */
define('SITE_NAME', 'PRIVATE CLUB');
define('SITE_TAGLINE', 'Members Only. Silent Power.');
define('SITE_TIMEZONE', 'Asia/Dhaka');

/* -----------------------------------------
   ADMIN IDENTITY (ROOT)
------------------------------------------ */
define('ROOT_ADMIN_EMAIL', 'angkur490@gmail.com');

/* -----------------------------------------
   SESSION & SECURITY
------------------------------------------ */
define('SESSION_TIMEOUT', 60 * 60 * 4); // 4 hours
define('PASSWORD_MIN_LENGTH', 8);

/* -----------------------------------------
   MEMBERSHIP DEFAULTS
------------------------------------------ */
define('DEFAULT_PLAN_DAYS', 30);
define('ALLOW_LIFETIME_ACCESS', true);

/* -----------------------------------------
   FEATURE FLAGS
------------------------------------------ */
define('FEATURE_AUDIT_LOGS', true);
define('FEATURE_IMPERSONATION', true);
define('FEATURE_MANUAL_PAYMENTS', true);
define('FEATURE_AUTO_EXPIRY', true);

/* -----------------------------------------
   RATE LIMITING (FUTURE)
------------------------------------------ */
define('LOGIN_ATTEMPT_LIMIT', 5);
define('LOGIN_COOLDOWN_SECONDS', 300);

/* -----------------------------------------
   ENVIRONMENT
------------------------------------------ */
/**
 * development = show errors
 * production  = hide errors
 */
define('APP_ENV', 'development'); // CHANGE TO production LATER

/* -----------------------------------------
   ERROR DISPLAY CONTROL
------------------------------------------ */
if (APP_ENV === 'development') {
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', 0);
    error_reporting(0);
}

/* -----------------------------------------
   TIMEZONE APPLY
------------------------------------------ */
date_default_timezone_set(SITE_TIMEZONE);

/* -----------------------------------------
   PAYMENT DETAILS (ADMIN CONTROLLED)
------------------------------------------ */
define('BKASH_NUMBER', '01788674353');
define('NAGAD_NUMBER', '01788674353');
define('PAYMENT_RECEIVER_NAME', 'Angkur');