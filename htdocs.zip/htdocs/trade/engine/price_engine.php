<?php
/**
 * ============================================
 * UC PRICE ENGINE
 * File: /trade/engine/price_engine.php
 * ============================================
 * - Generates next UC price
 * - Does NOT touch balances
 * - Controlled, but looks natural
 */

if (!defined('UC_ENGINE')) {
    die("DIRECT ACCESS BLOCKED");
}

/* ================= CONFIG ================= */
define('BASE_VOLATILITY', 0.002);   // 0.2%
define('FAST_VOLATILITY', 0.006);   // when no traders
define('SLOW_VOLATILITY', 0.001);   // when single trader

/* ================= HELPERS ================= */
function rand_float($min, $max) {
    return $min + mt_rand() / mt_getrandmax() * ($max - $min);
}

/* ================= CORE FUNCTION ================= */
/**
 * @param float $price          Current UC price
 * @param array $positions      Open positions
 * @return float                New price
 */
function generate_uc_price(float $price, array $positions): float
{
    $count = count($positions);

    /* ========= CASE 1: NO TRADERS ========= */
    if ($count === 0) {
        $move = rand_float(-FAST_VOLATILITY, FAST_VOLATILITY);
        return max(0.01, $price * (1 + $move));
    }

    /* ========= CASE 2: ONE TRADER ========= */
    if ($count === 1) {

        $p = $positions[0];

        // if user LONG → price drifts down
        // if user SHORT → price drifts up
        $direction = ($p['side'] === 'long') ? -1 : 1;

        $move = rand_float(0.0003, SLOW_VOLATILITY) * $direction;

        // add tiny noise so it doesn't look fixed
        $noise = rand_float(-0.0002, 0.0002);

        return max(0.01, $price * (1 + $move + $noise));
    }

    /* ========= CASE 3: MULTIPLE TRADERS ========= */

    // find highest exposure
    $longExposure  = 0;
    $shortExposure = 0;

    foreach ($positions as $p) {
        $exposure = $p['amount'] * $p['leverage'];

        if ($p['side'] === 'long') {
            $longExposure += $exposure;
        } else {
            $shortExposure += $exposure;
        }
    }

    // hunt the heavier side
    if ($longExposure > $shortExposure) {
        $direction = -1; // drop price
    } elseif ($shortExposure > $longExposure) {
        $direction = 1;  // pump price
    } else {
        $direction = rand(0,1) ? 1 : -1;
    }

    $move = rand_float(0.0008, BASE_VOLATILITY) * $direction;
    $noise = rand_float(-0.0004, 0.0004);

    return max(0.01, $price * (1 + $move + $noise));
}