<?php
/*********************************************************
 * SESSION & DATABASE
 *********************************************************/
session_start();
require_once "../db.php";

/* Force UTF-8 (Bangla + Emoji) */
$db->exec("SET NAMES utf8mb4");

/* Authentication */
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit;
}
$uid = (int)$_SESSION['user_id'];

/*********************************************************
 * UPDATE LAST SEEN
 *********************************************************/
$db->prepare(
    "UPDATE users SET last_seen = NOW() WHERE id = ?"
)->execute([$uid]);

/*********************************************************
 * ACTIVE CHAT USER
 *********************************************************/
$chatUserId = isset($_GET['u']) ? (int)$_GET['u'] : 0;

/*********************************************************
 * MEDIA UPLOAD (HEADER 📎 BUTTON)
 *********************************************************/
if (isset($_POST['upload_media']) && $chatUserId) {

    if (!empty($_FILES['media']['name'])) {

        $ext = pathinfo($_FILES['media']['name'], PATHINFO_EXTENSION);
        $filename = time() . "_" . uniqid() . "." . $ext;

        $target = __DIR__ . "/uploads/chat/" . $filename;

        if (move_uploaded_file($_FILES['media']['tmp_name'], $target)) {
            $db->prepare("
                INSERT INTO chat_messages
                (sender_id, receiver_id, message, image, seen)
                VALUES (?, ?, '', ?, 0)
            ")->execute([$uid, $chatUserId, $filename]);
        }
    }

    header("Location: indexx.php?u=".$chatUserId."#bottom");
    exit;
}

/*********************************************************
 * SEND TEXT MESSAGE
 *********************************************************/
if (isset($_POST['send_msg']) && $chatUserId) {

    $msg = trim($_POST['msg'] ?? '');

    if ($msg !== '') {
        $db->prepare("
            INSERT INTO chat_messages
            (sender_id, receiver_id, message, seen)
            VALUES (?, ?, ?, 0)
        ")->execute([$uid, $chatUserId, $msg]);
    }

    header("Location: indexx.php?u=".$chatUserId."#bottom");
    exit;
}

/*********************************************************
 * FETCH CHAT USER INFO
 *********************************************************/
$chatUser = null;
if ($chatUserId) {
    $stmt = $db->prepare(
        "SELECT id, name, photo FROM users WHERE id = ?"
    );
    $stmt->execute([$chatUserId]);
    $chatUser = $stmt->fetch(PDO::FETCH_ASSOC);

    /* Mark messages as seen */
    $db->prepare("
        UPDATE chat_messages
        SET seen = 1
        WHERE sender_id = ? AND receiver_id = ?
    ")->execute([$chatUserId, $uid]);
}

/*********************************************************
 * USER LIST (LEFT SIDEBAR)
 *********************************************************/
$users = $db->query("
    SELECT u.*,
    (
        SELECT COUNT(*)
        FROM chat_messages
        WHERE sender_id = u.id
        AND receiver_id = $uid
        AND seen = 0
    ) AS unread
    FROM users u
    WHERE u.id != $uid
    AND u.role NOT IN ('SYSTEM','LIQUIDITY')
    ORDER BY name ASC
")->fetchAll(PDO::FETCH_ASSOC);

/*********************************************************
 * FETCH CHAT MESSAGES
 *********************************************************/
$messages = [];
if ($chatUserId) {
    $stmt = $db->prepare("
        SELECT sender_id, message, image, seen
        FROM chat_messages
        WHERE (sender_id = ? AND receiver_id = ?)
           OR (sender_id = ? AND receiver_id = ?)
        ORDER BY id ASC
    ");
    $stmt->execute([$uid, $chatUserId, $chatUserId, $uid]);
    $messages = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Chat</title>

<style>
/*********************************************************
 * GLOBAL
 *********************************************************/
*{
    box-sizing:border-box;
    font-family:
        system-ui,
        "Noto Sans Bengali",
        "Noto Color Emoji",
        "Apple Color Emoji",
        sans-serif;
}

body{
    margin:0;
    height:100vh;
    background:#0b141a;
    color:#e9edef;
}

.app{
    height:100vh;
}

/*********************************************************
 * SIDEBAR
 *********************************************************/
.sidebar{
    background:#111b21;
    overflow-y:auto;
}

.user{
    margin:8px;
    padding:12px;
    border-radius:12px;
    background:#1f2c33;
    display:flex;
    align-items:center;
    gap:12px;
    color:#fff;
    text-decoration:none;
}

.user img{
    width:42px;
    height:42px;
    border-radius:50%;
    object-fit:cover;
}

.badge{
    margin-left:auto;
    background:#00a884;
    color:#000;
    min-width:22px;
    height:22px;
    border-radius:11px;
    display:flex;
    align-items:center;
    justify-content:center;
    font-size:12px;
}

/*********************************************************
 * CHAT CONTAINER
 *********************************************************/
.chat{
    display:none;
}

.chat.active{
    display:flex;
    flex-direction:column;
    position:fixed;
    inset:0;
    background:#0b141a;
}

/*********************************************************
 * HEADER
 *********************************************************/
.chat-header{
    height:56px;
    background:#202c33;
    display:grid;
    grid-template-columns:48px 1fr 48px;
    align-items:center;
}

.chat-header a{
    text-align:center;
    font-size:22px;
    color:#00a884;
    text-decoration:none;
}

/*********************************************************
 * MESSAGES AREA
 *********************************************************/
.messages{
    flex:1;
    padding:12px;
    overflow-y:auto;
    background:url('uploads/bg/bgl.png') center/cover no-repeat;
}

/*********************************************************
 * MESSAGE BUBBLES (FIXED HEIGHT ISSUE)
 *********************************************************/
.msg{
    width:fit-content;
    max-width:75%;
    padding:6px 10px;
    margin-bottom:6px;
    border-radius:10px;
    font-size:15px;
    line-height:1.4;
    white-space:normal;
    word-break:break-word;
}

.me{
    background:#005c4b;
    margin-left:auto;
    border-bottom-right-radius:4px;
}

.them{
    background:#202c33;
    border-bottom-left-radius:4px;
}

.meta{
    font-size:11px;
    opacity:.6;
    text-align:right;
}

.msg img{
    max-width:180px;
    border-radius:8px;
    display:block;
}

/*********************************************************
 * INPUT AREA
 *********************************************************/
.input{
    display:flex;
    gap:8px;
    padding:8px;
    background:#202c33;
}

.input input[type=text]{
    flex:1;
    height:38px;
    border:none;
    border-radius:19px;
    padding:0 14px;
    background:#2a3942;
    color:#fff;
}

.input button{
    height:38px;
    border:none;
    border-radius:19px;
    padding:0 16px;
    background:#00a884;
}

/*********************************************************
 * DESKTOP
 *********************************************************/
@media(min-width:900px){
    .app{display:flex}
    .sidebar{width:360px}
    .chat{display:flex;position:relative}
}
</style>
</head>

<body>

<div class="app">

<!-- SIDEBAR -->
<div class="sidebar">
<?php foreach($users as $u): ?>
<a class="user" href="indexx.php?u=<?= $u['id'] ?>">
<img src="../uploads/avatars/<?= htmlspecialchars($u['photo']) ?>">
<?= htmlspecialchars($u['name']) ?>
<?php if($u['unread']>0): ?>
<span class="badge"><?= $u['unread'] ?></span>
<?php endif; ?>
</a>
<?php endforeach; ?>
</div>

<!-- CHAT -->
<?php if($chatUser): ?>
<div class="chat active">

<div class="chat-header">
<a href="indexx.php">✕</a>

<div style="text-align:center;font-weight:600">
<?= htmlspecialchars($chatUser['name']) ?>
</div>

<form method="post" enctype="multipart/form-data">
<input type="hidden" name="upload_media">
<label style="cursor:pointer">
📎
<input type="file" name="media" accept="image/*"
       style="display:none"
       onchange="this.form.submit()">
</label>
</form>
</div>

<div class="messages">
<?php foreach($messages as $m): ?>
<div class="msg <?= $m['sender_id']==$uid?'me':'them' ?>">
<?php if($m['image']): ?>
<img src="uploads/chat/<?= htmlspecialchars($m['image']) ?>">
<?php else: ?>
<?= htmlspecialchars($m['message']) ?>
<?php endif; ?>
<div class="meta">
<?= $m['sender_id']==$uid ? ($m['seen']?'✓✓':'✓') : '' ?>
</div>
</div>
<?php endforeach; ?>
<div id="bottom"></div>
</div>

<form method="post" class="input">
<input type="hidden" name="send_msg">
<input type="text" name="msg" placeholder="Message…">
<button>Send</button>
</form>

</div>
<?php endif; ?>

</div>
</body>
</html>