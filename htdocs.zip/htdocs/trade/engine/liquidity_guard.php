<?php
/**
 * ============================================
 * UC LIQUIDITY GUARD
 * File: /trade/engine/liquidity_guard.php
 * ============================================
 * - Prevents system bankruptcy
 * - Caps max loss per cycle
 * - Invisible to users
 */

if (!defined('UC_ENGINE')) {
    die("DIRECT ACCESS BLOCKED");
}

/* ================= CONFIG ================= */

// Admin controlled (later from DB)
define('MIN_SYSTEM_BALANCE', 100); // UC (example)
define('MAX_LOSS_PER_CYCLE', 5);   // UC

/* ================= CORE FUNCTION ================= */
/**
 * Determines whether price movement is allowed
 *
 * @param float $systemBalance   Current system UC balance
 * @param float $expectedLoss    Loss if market continues
 * @return bool
 */
function allow_market_move(float $systemBalance, float $expectedLoss): bool
{
    // hard floor
    if (($systemBalance - $expectedLoss) < MIN_SYSTEM_BALANCE) {
        return false;
    }

    // max loss per cycle
    if ($expectedLoss > MAX_LOSS_PER_CYCLE) {
        return false;
    }

    return true;
}

/* ================= DIRECTION OVERRIDE ================= */
/**
 * Forces market to reverse if system is unsafe
 *
 * @param float $systemBalance
 * @param float $expectedLoss
 * @param int   $currentDirection (1 = up, -1 = down)
 * @return int
 */
function protect_system(
    float $systemBalance,
    float $expectedLoss,
    int $currentDirection
): int {
    if (!allow_market_move($systemBalance, $expectedLoss)) {
        return -$currentDirection; // reverse market
    }

    return $currentDirection;
}